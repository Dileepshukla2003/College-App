package com.example.ikgptuamritsaradmin.atenndacesheet;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageButton;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.FileProvider;

import com.example.ikgptuamritsaradmin.R;
import com.itextpdf.io.font.FontConstants;
import com.itextpdf.kernel.colors.DeviceGray;
import com.itextpdf.kernel.font.PdfFont;
import com.itextpdf.kernel.font.PdfFontFactory;
import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.property.TextAlignment;
import com.itextpdf.layout.property.UnitValue;
import com.itextpdf.layout.property.VerticalAlignment;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;


public class SheetActivity extends AppCompatActivity {

    Toolbar toolbar;
    private String className;
    private String subjectName;
    private int position;
    TextView subtitle;
    private String month;
    TableLayout tableLayout;
    private int rowsize;
    long[] idArray;
    private int[] rollArray;
    private String[] nameArray;
    private int DAY_IN_MONTH;
    private TextView[][] status_tvs;
     private DbHelper dbHelper;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sheet);
        getSupportActionBar().hide();
        Intent intent=getIntent();
        className=intent.getStringExtra("className");
        subjectName=intent.getStringExtra("subjectName");
        month = intent.getStringExtra("month");
        rollArray = intent.getIntArrayExtra("rollArray");
        nameArray = intent.getStringArrayExtra("nameArray");

        idArray = intent.getLongArrayExtra("idArray");
        rowsize = idArray.length + 1;
        DAY_IN_MONTH = getDayInMonth(month);
        dbHelper = new DbHelper(this);


//        position=intent.getIntExtra("position",-1);
//        cid=intent.getLongExtra("cid",-1);
        setToolbar();
        showTable();
        showTablenames();
    }

    private void showTablenames() {
        TextView subjectNameTextView = findViewById(R.id.subject_name);
        TextView classNameTextView = findViewById(R.id.class_name);
        TextView monthYearTextView = findViewById(R.id.month_year);

        subjectNameTextView.setText(subjectName);
        classNameTextView.setText(className);

        monthYearTextView.setText(month);
    }

    private void showTable() {
        DbHelper dbHelper = new DbHelper(this);
        TableLayout tableLayout = findViewById(R.id.tableLayout);
        // Retrieve intent data
        Intent intent = getIntent();
        className = intent.getStringExtra("className");
        subjectName = intent.getStringExtra("subjectName");
        String month = intent.getStringExtra("month");
        long[] idArray = intent.getLongArrayExtra("idArray");
        int[] rollArray = intent.getIntArrayExtra("rollArray");
        String[] nameArray = intent.getStringArrayExtra("nameArray");

        int DAY_IN_MONTH = getDayInMonth(month);

        //row setup
        int rowsize = idArray.length + 1;
        TableRow[] rows = new TableRow[rowsize];
        TextView[] rool_tvs = new TextView[rowsize];
        TextView[] name_tvs = new TextView[rowsize];
        TextView[][] status_tvs = new TextView[rowsize][DAY_IN_MONTH + 1];
        for (int i = 0; i < rowsize; i++) {
            rool_tvs[i] = new TextView(this);
            name_tvs[i] = new TextView(this);
            for (int j = 1; j <= DAY_IN_MONTH; j++) { // Change condition to j <= DAY_IN_MONTH
                status_tvs[i][j] = new TextView(this);
            }


        }
        //header
        rool_tvs[0].setText("Roll");
        rool_tvs[0].setTypeface(rool_tvs[0].getTypeface(), Typeface.BOLD);
        name_tvs[0].setText("Name");
        name_tvs[0].setTypeface(name_tvs[0].getTypeface(), Typeface.BOLD);
        for (int i = 1; i <= DAY_IN_MONTH; i++) {
            status_tvs[0][i].setText(String.valueOf(i));
            status_tvs[0][i].setTypeface(status_tvs[0][i].getTypeface(), Typeface.BOLD);
        }
        for (int i = 1; i < rowsize; i++) {
            rool_tvs[i].setText(String.valueOf(rollArray[i - 1]));
            name_tvs[i].setText(nameArray[i - 1]);
            for (int j = 1; j <= DAY_IN_MONTH; j++) {
                String day = String.valueOf(j);
                if (day.length() == 1) day = "0" + day;
                String date = day + "." + month;

                String status = dbHelper.getStatus(idArray[i - 1], date);
                Log.d("SheetActivity", "Date: " + date + ", Status: " + status);
                status_tvs[i][j].setText(status);
            }

        }

        int[] colors = {
                Color.parseColor("#EEEEEE"), // Light gray
                Color.parseColor("#E4E4E4")  // Light gray alternate color
        };

        for (int i = 0; i < rowsize; i++) {
            rows[i] = new TableRow(this);

            rows[i].setBackgroundColor(colors[i % 2]); // Set background color using predefined colors

            rool_tvs[i].setPadding(16, 16, 16, 16);
            name_tvs[i].setPadding(16, 16, 16, 16);
            rows[i].addView(rool_tvs[i]);
            rows[i].addView(name_tvs[i]);

            for (int j = 1; j <= DAY_IN_MONTH; j++) {
                status_tvs[i][j].setPadding(16, 16, 16, 16);
                rows[i].addView(status_tvs[i][j]);
            }

            tableLayout.addView(rows[i]);
        }

        tableLayout.setShowDividers(TableLayout.SHOW_DIVIDER_MIDDLE);
    }



    private int getDayInMonth(String month) {
        String[] parts = month.split("\\."); // Split the month string into parts
        if (parts.length == 2) {
            int monthIndex = Integer.parseInt(parts[0]) - 1; // Subtract 1 to get the correct month index
            int year = Integer.parseInt(parts[1]); // Extract the year

            Calendar calendar = Calendar.getInstance();
            calendar.set(Calendar.MONTH, monthIndex);
            calendar.set(Calendar.YEAR, year);
            return calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
        }
        return 0; // Return 0 as a default value if something goes wrong
    }


    private int getMonthIndex(String monthName) {
        String[] months = {
                "January", "February", "March", "April", "May", "June",
                "July", "August", "September", "October", "November", "December"
        };

        for (int i = 0; i < months.length; i++) {
            if (months[i].equalsIgnoreCase(monthName)) {
                return i;
            }
        }
        return -1; // Return -1 if the month name is not found
    }

    // ... Rest of the code ...
    private void setToolbar() {
        toolbar=findViewById(R.id.toolbar);
        subtitle=toolbar.findViewById(R.id.subtitle_toolbar);
        TextView title=toolbar.findViewById(R.id.title_toolbar);
        ImageButton back=toolbar.findViewById(R.id.back);
        ImageButton save=toolbar.findViewById(R.id.save);
        title.setText(className);
        subtitle.setText(subjectName);
        save.setOnClickListener(v -> generateAndSavePDF());
        back.setOnClickListener(v-> onBackPressed());
    }
    private void generateAndSavePDF() {
        try {
            File pdfFile = new File(getFilesDir(), "attendance_sheet.pdf");
            FileOutputStream outputStream = new FileOutputStream(pdfFile);

            PdfWriter pdfWriter = new PdfWriter(outputStream);
            PdfDocument pdfDocument = new PdfDocument(pdfWriter);

            PageSize pageSize = PageSize.A4.rotate();

            // Create the document and set margins
            Document document = new Document(pdfDocument, pageSize);
            document.setMargins(30, 30, 30, 30);

            // Add title
            Paragraph titleParagraph = new Paragraph("Attendance Sheet")
                    .setFont(PdfFontFactory.createFont(FontConstants.HELVETICA_BOLD))
                    .setFontSize(20)
                    .setTextAlignment(TextAlignment.CENTER);
            document.add(titleParagraph);

            // Add class name, subject name, and month-year
            Paragraph classSubjectMonthParagraph = new Paragraph(className + " - " + subjectName + " - " + month)
                    .setFont(PdfFontFactory.createFont(FontConstants.HELVETICA))
                    .setFontSize(14)
                    .setTextAlignment(TextAlignment.CENTER);
            document.add(classSubjectMonthParagraph);

            // Add an empty line
            document.add(new Paragraph("\n"));

            // Create a table
            Table attendanceTable = createAttendanceTable();

// Add the table to the document
            document.add(attendanceTable);
            // Add footer with generation date and time
            Paragraph footer = new Paragraph("Generated on: " + getCurrentDateTime())
                    .setFont(PdfFontFactory.createFont(FontConstants.HELVETICA_OBLIQUE))
                    .setFontSize(10)
                    .setTextAlignment(TextAlignment.RIGHT);
            document.add(footer);

            // Close the document
            document.close();

            // Open the saved PDF file using an intent
            openPdfFile(pdfFile);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    private Table createAttendanceTable() {
        Table table = new Table(UnitValue.createPercentArray(getTableColumnWidths()));
        table.addCell(createCell("Roll", true));
        table.addCell(createCell("Name", true));
        for (int i = 1; i <= DAY_IN_MONTH; i++) {
            table.addCell(createCell(String.valueOf(i), true));
        }
        for (int i = 1; i < rowsize; i++) {
            Log.d("SheetActivity", "Roll: " + rollArray[i - 1] + ", Name: " + nameArray[i - 1] + ", ID: " + idArray[i - 1]);

            table.addCell(createCell(String.valueOf(rollArray[i - 1]), false));
            table.addCell(createCell(nameArray[i - 1], false));



            for (int j = 1; j <= DAY_IN_MONTH; j++) {
                String day = String.valueOf(j);
                if (day.length() == 1) day = "0" + day;
                String date = day + "." + month;


                String status = dbHelper.getStatus(idArray[i - 1], date);
                Log.d("SheetActivity", "Getting status for ID: " + idArray[i - 1] + ", Date: " + date);

                table.addCell(createCell(status, false));
            }
        }

        return table;
    }

    private float[] getTableColumnWidths() {
        int DAY_IN_MONTH = getDayInMonth(month);
        float[] columnWidths = new float[DAY_IN_MONTH + 2]; // +2 for Roll and Name columns
        columnWidths[0] = 10f; // Roll column width
        columnWidths[1] = 30f; // Name column width

        // Set width for each date column
        for (int i = 2; i < columnWidths.length; i++) {
            columnWidths[i] = 60f / DAY_IN_MONTH;
        }

        // Log the calculated column widths
        for (int i = 0; i < columnWidths.length; i++) {
            Log.d("getColumnWidths", "Column " + i + " width: " + columnWidths[i]);
        }

        return columnWidths;
    }
    private String getCurrentDateTime() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        return sdf.format(Calendar.getInstance().getTime());
    }


    private Cell createCell(String content, boolean isHeader) {
        PdfFont font;
        try {
            font = isHeader ? PdfFontFactory.createFont(FontConstants.HELVETICA_BOLD) : PdfFontFactory.createFont(FontConstants.HELVETICA);
        } catch (IOException e) {
            e.printStackTrace();
            return new Cell(); // Return an empty cell in case of an exception
        }

        // Ensure background color intensity values are valid
        float backgroundColorIntensity = isHeader ? 0.7f : 0.9f;
        if (backgroundColorIntensity < 0.0f) {
            backgroundColorIntensity = 0.0f;
        } else if (backgroundColorIntensity > 1.0f) {
            backgroundColorIntensity = 1.0f;
        }

        // Handle empty or null content
        if (content == null || content.isEmpty()) {
            content = ""; // Provide a default value
        }

        Cell cell = new Cell()
                .add(new Paragraph(content).setFont(font))
                .setBackgroundColor(new DeviceGray(backgroundColorIntensity))
                .setTextAlignment(TextAlignment.CENTER)
                .setVerticalAlignment(VerticalAlignment.MIDDLE);

        return cell;
    }
    private void openPdfFile(File pdfFile) {
        Uri pdfUri = FileProvider.getUriForFile(this, "com.example.ikgptuamritsaradmin.fileprovider", pdfFile);

        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setDataAndType(pdfUri, "application/pdf");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

        try {
            startActivity(intent);
        } catch (ActivityNotFoundException e) {
            e.printStackTrace();
            // Handle the case where a PDF viewer app is not installed on the device
            Toast.makeText(this, "No PDF viewer app installed", Toast.LENGTH_SHORT).show();
        }
    }




}
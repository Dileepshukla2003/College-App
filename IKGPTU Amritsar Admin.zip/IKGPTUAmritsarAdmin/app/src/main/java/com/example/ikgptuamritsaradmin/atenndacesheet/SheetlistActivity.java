package com.example.ikgptuamritsaradmin.atenndacesheet;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

import com.example.ikgptuamritsaradmin.R;

import java.util.ArrayList;

public class SheetlistActivity extends AppCompatActivity {
    private ListView sheetList;
    Toolbar toolbar;
    private String className;
    private String subjectName;
    private int position;
    TextView subtitle;
    private ArrayAdapter<String> adapter; // Specify the type of ArrayAdapter
    private ArrayList<String> listItems = new ArrayList<>(); // Specify the type of ArrayList
    private long cid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sheetlist);
        getSupportActionBar().hide();

        // Retrieve the cid from the intent
//        cid = getIntent().getLongExtra("cid", -1);
        Intent intent=getIntent();
        className=intent.getStringExtra("className");
        subjectName=intent.getStringExtra("subjectName");
        position=intent.getIntExtra("position",-1);
        cid=intent.getLongExtra("cid",-1);

        setToolbar();

        Log.i("1234567890", "onCreate: " + cid);

        sheetList = findViewById(R.id.sheetList);
        adapter = new ArrayAdapter<>(this, R.layout.sheet_list, R.id.date_list_item, listItems);
        sheetList.setAdapter(adapter);
        sheetList.setOnItemClickListener((parent, view, position1, id) -> openSheetActivity(position1));


        loadListItems(); // Call this method after initializing the adapter
    }

//    private void openSheetActivity(int position) {
//        long[] idArray=getIntent().getLongArrayExtra("idArray");
//        int[] rollArray=getIntent().getIntArrayExtra("rollArray");
//        String[] nameArray=getIntent().getStringArrayExtra("nameArray");
//
//
//        Intent intent = new Intent(this, SheetActivity.class);
//        intent.putExtra("className",className);
//        intent.putExtra("subjectName",subjectName);
////        intent.putExtra("position",position);
////        intent.putExtra("cid", cid); // Pass the cid to SheetlistActivity
//        //
//        intent.putExtra("idArray",idArray);
//        intent.putExtra("rollArray",rollArray);
//        intent.putExtra("nameArray",nameArray);
//        intent.putExtra("month",listItems.get(position));
//        startActivity(intent);
//
//    }
private void openSheetActivity(int position1) {
    long[] idArray = getIntent().getLongArrayExtra("idArray");
    int[] rollArray = getIntent().getIntArrayExtra("rollArray");
    String[] nameArray = getIntent().getStringArrayExtra("nameArray");

    Intent intent = new Intent(this, SheetActivity.class);
    intent.putExtra("className", className);
    intent.putExtra("subjectName", subjectName);
    intent.putExtra("idArray", idArray);
    intent.putExtra("rollArray", rollArray);
    intent.putExtra("nameArray", nameArray);
    intent.putExtra("month", listItems.get(position1)); // Use position1 here
    startActivity(intent);
}



    private void setToolbar() {
        toolbar=findViewById(R.id.toolbar);
        subtitle=toolbar.findViewById(R.id.subtitle_toolbar);
        TextView title=toolbar.findViewById(R.id.title_toolbar);

        ImageButton back=toolbar.findViewById(R.id.back);
        ImageButton save=toolbar.findViewById(R.id.save);



        title.setText(className);
        subtitle.setText(subjectName);
        save.setVisibility(View.INVISIBLE);

        back.setOnClickListener(v-> onBackPressed());


    }


    private void loadListItems() {
        Cursor cursor = new DbHelper(this).getDistinctMonths(cid);

        if (cursor != null) {
            try {
                if (cursor.moveToFirst()) {
                    int dateColumnIndex = cursor.getColumnIndexOrThrow("substr(" + DbHelper.DATE_KEY + ", 4, 7)");

                    do {
                        String date = cursor.getString(dateColumnIndex);
                        String[] parts = date.split("\\.");
                        if (parts.length == 2) {
                            int month = Integer.parseInt(parts[0]);
                            int year = Integer.parseInt(parts[1]);

                            // Format month and year with leading zeros if needed
                            String formattedMonth = String.format("%02d", month);
                            String formattedYear = String.format("%04d", year);

                            // Create the formatted date string
                            String formattedDate = formattedMonth + "." + formattedYear;
                            listItems.add(formattedDate);
                        }
                    } while (cursor.moveToNext());

                    adapter.notifyDataSetChanged();
                } else {
                    Log.e("LoadListItems", "Cursor is empty");
                }
            } finally {
                cursor.close();
            }
        } else {
            Log.e("LoadListItems", "Cursor is null");
        }
    }


    private String getMonthName(int month) {
        String[] months = {
                "January", "February", "March", "April", "May", "June", "July",
                "August", "September", "October", "November", "December"
        };
        if (month >= 1 && month <= 12) {
            return months[month - 1];
        }
        return "Unknown";
    }


}

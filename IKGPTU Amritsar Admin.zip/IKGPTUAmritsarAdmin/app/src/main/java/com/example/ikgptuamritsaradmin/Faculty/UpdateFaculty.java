package com.example.ikgptuamritsaradmin.Faculty;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.ikgptuamritsaradmin.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class UpdateFaculty extends AppCompatActivity {
    FloatingActionButton fab;
    private RecyclerView csDeparment,mechnicalDeparment,physicsDeparment,chemistryDeparment,mathDeparment,adminDeparment,nonTeaching;
    private LinearLayout csNoData,mechNoData,physicsNoData,chemistryNoData,mathNoData,adminNoData,nonteachingNoData;
    private List<TeacherData> list0,list1,list2,list3,list4,list5,list6;
    private DatabaseReference reference,dbRef;
    private TeacherAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_faculty);
       getSupportActionBar().setTitle("Faculty Information");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        fab=findViewById(R.id.fab);

        csDeparment=findViewById(R.id.csDeparment);
        mechnicalDeparment=findViewById(R.id.mechnicalDeparment);
        physicsDeparment=findViewById(R.id.physicsDeparment);
        chemistryDeparment=findViewById(R.id.chemistryDeparment);
        mathDeparment=findViewById(R.id.mathDeparment);
        adminDeparment=findViewById(R.id.adminDeparment);
        nonTeaching=findViewById(R.id.nonTeaching);

        csNoData=findViewById(R.id.csNoData);
        mechNoData=findViewById(R.id.mechNoData);
        physicsNoData=findViewById(R.id.physicsNoData);
        chemistryNoData=findViewById(R.id.chemistryNoData);
        mathNoData=findViewById(R.id.mathNoData);
        adminNoData=findViewById(R.id.adminNoData);
        nonteachingNoData=findViewById(R.id.nonteachingNoData);

        csDeparment();
        mechnicalDeparment();
        physicsDeparment();
        chemistryDeparment();
        mathDeparment();
        adminDeparment();
        nonTeaching();




        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(UpdateFaculty.this,AddTeacher.class));
            }
        });

    }

    private void adminDeparment() {

        reference= FirebaseDatabase.getInstance().getReference().child("teacher").child("Admin Deparment");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                list0=new ArrayList<>();
                if(!dataSnapshot.exists()){
                    adminNoData.setVisibility(View.VISIBLE);
                    adminDeparment.setVisibility(View.GONE);
                }else{
                    adminNoData.setVisibility(View.GONE);
                    adminDeparment.setVisibility(View.VISIBLE);
                    for (DataSnapshot snapshot:dataSnapshot.getChildren()) {
                        TeacherData data = snapshot.getValue(TeacherData.class);
                        list0.add(data);

                    }
                    adminDeparment.setHasFixedSize(true);
                    adminDeparment.setLayoutManager(new LinearLayoutManager(UpdateFaculty.this));
                    adapter =new TeacherAdapter(list0,UpdateFaculty.this,"Admin Deparment");
                    adminDeparment.setAdapter(adapter);
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(UpdateFaculty.this,databaseError.getMessage(), Toast.LENGTH_SHORT).show();

            }
        });
    }

    private void csDeparment() {

        reference= FirebaseDatabase.getInstance().getReference().child("teacher").child("Computer Science & Engineering Department");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                list1=new ArrayList<>();
                if(!dataSnapshot.exists()){
                    csNoData.setVisibility(View.VISIBLE);
                    csDeparment.setVisibility(View.GONE);
                }else{
                    csNoData.setVisibility(View.GONE);
                    csDeparment.setVisibility(View.VISIBLE);
                    for (DataSnapshot snapshot:dataSnapshot.getChildren()) {
                        TeacherData data = snapshot.getValue(TeacherData.class);
                        list1.add(data);

                    }
                    csDeparment.setHasFixedSize(true);
                    csDeparment.setLayoutManager(new LinearLayoutManager(UpdateFaculty.this));
                    adapter =new TeacherAdapter(list1,UpdateFaculty.this,"Computer Science & Engineering Department");
                    csDeparment.setAdapter(adapter);
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(UpdateFaculty.this,databaseError.getMessage(), Toast.LENGTH_SHORT).show();

            }
        });
    }

    private void mechnicalDeparment() {
        reference= FirebaseDatabase.getInstance().getReference().child("teacher").child("Mechnical Engineering Department");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                list2=new ArrayList<>();
                if(!dataSnapshot.exists()){
                    mechNoData.setVisibility(View.VISIBLE);
                    mechnicalDeparment.setVisibility(View.GONE);
                }else{
                    mechNoData.setVisibility(View.GONE);
                    mechnicalDeparment.setVisibility(View.VISIBLE);
                    for (DataSnapshot snapshot:dataSnapshot.getChildren()) {
                        TeacherData data = snapshot.getValue(TeacherData.class);
                        list2.add(data);

                    }
                    mechnicalDeparment.setHasFixedSize(true);
                    mechnicalDeparment.setLayoutManager(new LinearLayoutManager(UpdateFaculty.this));
                    adapter =new TeacherAdapter(list2,UpdateFaculty.this,"Mechnical Engineering Department");
                    mechnicalDeparment.setAdapter(adapter);
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(UpdateFaculty.this,error.getMessage(), Toast.LENGTH_SHORT).show();

            }
        });
    }

    private void physicsDeparment() {
        reference= FirebaseDatabase.getInstance().getReference().child("teacher").child("Physics Deparment");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                list3=new ArrayList<>();
                if(!dataSnapshot.exists()){
                    physicsNoData.setVisibility(View.VISIBLE);
                    physicsDeparment.setVisibility(View.GONE);
                }else{
                    physicsNoData.setVisibility(View.GONE);
                    physicsDeparment.setVisibility(View.VISIBLE);
                    for (DataSnapshot snapshot:dataSnapshot.getChildren()) {
                        TeacherData data = snapshot.getValue(TeacherData.class);
                        list3.add(data);
                    }
                    physicsDeparment.setHasFixedSize(true);
                    physicsDeparment.setLayoutManager(new LinearLayoutManager(UpdateFaculty.this));
                    adapter =new TeacherAdapter(list3,UpdateFaculty.this,"Physics Deparment");
                    physicsDeparment.setAdapter(adapter);
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(UpdateFaculty.this,error.getMessage(), Toast.LENGTH_SHORT).show();

            }
        });
    }

    private void chemistryDeparment() {
        reference= FirebaseDatabase.getInstance().getReference().child("teacher").child("Chemistry Department");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                list4=new ArrayList<>();
                if(!dataSnapshot.exists()){
                    chemistryNoData.setVisibility(View.VISIBLE);
                    chemistryDeparment.setVisibility(View.GONE);
                }else{
                    chemistryNoData.setVisibility(View.GONE);
                    chemistryDeparment.setVisibility(View.VISIBLE);
                    for (DataSnapshot snapshot:dataSnapshot.getChildren()) {
                        TeacherData data = snapshot.getValue(TeacherData.class);
                        list4.add(data);
                    }
                    chemistryDeparment.setHasFixedSize(true);
                    chemistryDeparment.setLayoutManager(new LinearLayoutManager(UpdateFaculty.this));
                    adapter =new TeacherAdapter(list4,UpdateFaculty.this,"Chemistry Department");
                    chemistryDeparment.setAdapter(adapter);
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(UpdateFaculty.this,error.getMessage(), Toast.LENGTH_SHORT).show();

            }
        });
    }
    private void mathDeparment() {
        reference= FirebaseDatabase.getInstance().getReference().child("teacher").child("Mathematics Department");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                list5=new ArrayList<>();
                if(!dataSnapshot.exists()){
                    mathNoData.setVisibility(View.VISIBLE);
                    mathDeparment.setVisibility(View.GONE);
                }else{
                    mathNoData.setVisibility(View.GONE);
                    mathDeparment.setVisibility(View.VISIBLE);
                    for (DataSnapshot snapshot:dataSnapshot.getChildren()) {
                        TeacherData data = snapshot.getValue(TeacherData.class);
                        list5.add(data);
                    }
                    mathDeparment.setHasFixedSize(true);
                    mathDeparment.setLayoutManager(new LinearLayoutManager(UpdateFaculty.this));
                    adapter =new TeacherAdapter(list5,UpdateFaculty.this,"Mathematics Department");
                    mathDeparment.setAdapter(adapter);
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(UpdateFaculty.this,error.getMessage(), Toast.LENGTH_SHORT).show();

            }
        });
    }
    private void nonTeaching() {
        reference= FirebaseDatabase.getInstance().getReference().child("teacher").child("Non-Teaching Staff");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                list6=new ArrayList<>();
                if(!dataSnapshot.exists()){
                    nonteachingNoData.setVisibility(View.VISIBLE);
                    nonTeaching.setVisibility(View.GONE);
                }else{
                    nonteachingNoData.setVisibility(View.GONE);
                    nonTeaching.setVisibility(View.VISIBLE);
                    for (DataSnapshot snapshot:dataSnapshot.getChildren()) {
                        TeacherData data = snapshot.getValue(TeacherData.class);
                        list6.add(data);
                    }
                    nonTeaching.setHasFixedSize(true);
                    nonTeaching.setLayoutManager(new LinearLayoutManager(UpdateFaculty.this));
                    adapter =new TeacherAdapter(list6,UpdateFaculty.this,"Non-Teaching Staff");
                    nonTeaching.setAdapter(adapter);
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(UpdateFaculty.this,error.getMessage(), Toast.LENGTH_SHORT).show();

            }
        });
    }

}
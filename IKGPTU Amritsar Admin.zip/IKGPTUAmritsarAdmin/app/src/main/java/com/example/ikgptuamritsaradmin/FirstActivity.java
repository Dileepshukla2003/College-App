package com.example.ikgptuamritsaradmin;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.example.ikgptuamritsaradmin.security.LoginActivity1;

public class FirstActivity extends AppCompatActivity implements View.OnClickListener {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first);


        getSupportActionBar().setTitle("IKGPTU Amritsar Campus");


       CardView f = findViewById(R.id.ikgptuAdmin);
        f.setOnClickListener(this);
        CardView E = findViewById(R.id.ikgptuUser);
        E.setOnClickListener(this);

        if(!isConnected(FirstActivity.this)) {
            buildDialog(FirstActivity.this).show();
        }

    }
    public boolean isConnected(Context context) {
        ConnectivityManager manager = (ConnectivityManager) context.getSystemService(context.CONNECTIVITY_SERVICE);
        NetworkInfo info = manager.getActiveNetworkInfo();
        if (info != null && info.isConnectedOrConnecting()) {
            android.net.NetworkInfo wifi = manager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
            android.net.NetworkInfo mobile = manager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
            if ((mobile != null && mobile.isConnectedOrConnecting()) || (wifi != null && wifi.isConnectedOrConnecting()))
                return true;
            else return false;
        }else
            return false;
    }
    public AlertDialog.Builder buildDialog(Context context){
        final AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("No Internet Connection");
        builder.setCancelable(false);
        builder.setMessage("You need to have Internet Connection.Press OK to Exit.");

        builder.setPositiveButton("ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        });
        return builder;
    }

    @Override
    public void onClick(View v) {
        switch(v.getId()) {
            case R.id.ikgptuAdmin:
                Intent intent = new Intent(FirstActivity.this, LoginActivity.class);
                startActivity(intent);
                break;


        }
        switch(v.getId()) {
            case R.id.ikgptuUser:
                Intent intent1 = new Intent(FirstActivity.this, LoginActivity1.class);
                startActivity(intent1);
                break;


        }
    }
}
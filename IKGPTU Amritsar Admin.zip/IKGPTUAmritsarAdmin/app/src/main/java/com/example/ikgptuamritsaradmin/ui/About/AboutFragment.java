package com.example.ikgptuamritsaradmin.ui.About;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import com.example.ikgptuamritsaradmin.R;
import com.example.ikgptuamritsaradmin.User.MainActivity5;
import com.example.ikgptuamritsaradmin.User.MainActivity6;
import com.example.ikgptuamritsaradmin.User.MainActivity7;
import com.example.ikgptuamritsaradmin.ui.Home.SliderAdapterExample;
import com.smarteist.autoimageslider.IndicatorView.animation.type.IndicatorAnimationType;
import com.smarteist.autoimageslider.SliderAnimations;
import com.smarteist.autoimageslider.SliderView;

import java.util.ArrayList;
import java.util.List;


public class AboutFragment extends Fragment {
    private  int images[];
    private  String text[];
    private SliderAdapterExample adapter;
    private SliderView sliderView;
    private ViewPager viewPager;
    private BranchAdapter adapter1;
    private List<BranchModel> list;
    private ImageView imageView1,imageView2,imageView3;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_about, container, false);
        sliderView=view.findViewById(R.id.imageSlider);
        imageView1=view.findViewById(R.id.imageView1);
        imageView2=view.findViewById(R.id.imageView2);
        imageView3=view.findViewById(R.id.imageView3);
        images= new int[]{R.drawable.asr3, R.drawable.asr1,R.drawable.asr2, R.drawable.asr4, R.drawable.logo1};
        text=new String[]{"IKGPTU Amritsar Campus","IKGPTU Amritsar Campus","IKGPTU Amritsar Campus","IKGPTU Amritsar Campus","IKGPTU Amritsar Campus"};
        adapter=new SliderAdapterExample(images,text);
        sliderView.setSliderAdapter(adapter);
        sliderView.setSliderTransformAnimation(SliderAnimations.SIMPLETRANSFORMATION);
        sliderView.setIndicatorAnimation(IndicatorAnimationType.SLIDE);
        sliderView.startAutoCycle();


        list=new ArrayList<>();
        list.add(new BranchModel(R.drawable.ic_computer,"B. Tech. – Computer Science & Engineering (CSE)","B. Tech. – Computer Science & Engineering Started in 2016." +
                "   At present intake sheet in first - year is 60 student."));
        list.add(new BranchModel(R.drawable.ic_mechnical,"B. Tech. – Mechanical Engineering (ME)","B. Tech. – Mechanical Engineering  Started in 2016." +
                "  At present intake sheet in first - year is 60 student."));
        list.add(new BranchModel(R.drawable.ic_computer,"Bachelor of Computer Applications (BCA)","Bachelor of Computer Applications Started in 2016. " +
                "  At present intake sheet in first - year is 60 student."));
        list.add(new BranchModel(R.drawable.ic_computer,"M. Tech. – Computer Science & Engineering (CSE)","M. Tech. – Computer Science & Engineering Started in 2016. " +
                "  At present intake sheet in first - year is 18 student."));
        adapter1=new BranchAdapter(getContext(),list);
        viewPager=view.findViewById(R.id.viewPager);
        viewPager.setAdapter(adapter1);

        imageView1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), MainActivity5.class);
                startActivity(intent);
            }
        });
        imageView2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), MainActivity6.class);
                startActivity(intent);
            }
        });
        imageView3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), MainActivity7.class);
                startActivity(intent);
            }
        });




        return view;
    }

}
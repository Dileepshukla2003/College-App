package com.example.ikgptuamritsaradmin.ui.Faculty;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.ikgptuamritsaradmin.Faculty.TeacherData;
import com.example.ikgptuamritsaradmin.R;

import java.util.List;

public class TeacherAdapter1 extends RecyclerView.Adapter<TeacherAdapter1.TeacherViewAdapter>{
    private List<TeacherData> list;
    private Context context;


    public TeacherAdapter1(List<TeacherData> list,Context context) {
        this.list = list;
        this.context = context;

    }
    @NonNull
    @Override
    public TeacherViewAdapter onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.faculty_item_layout1,parent,false);
        return new TeacherAdapter1.TeacherViewAdapter(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TeacherViewAdapter holder, int position) {
        TeacherData item = list.get(position);
        holder.name.setText(item.getName());
        holder.email.setText(item.getEmail());
        holder.post.setText(item.getPost());
        try {
            Glide.with(context).load(item.getImage()).placeholder(R.drawable.tech).into(holder.imageView);
        } catch (Exception e) {
            e.printStackTrace();
        }


    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class TeacherViewAdapter extends RecyclerView.ViewHolder {
        private TextView name,email,post;

        private ImageView imageView;


        public TeacherViewAdapter(@NonNull View itemView) {
            super(itemView);
            name=itemView.findViewById(R.id.teacherName);
            email=itemView.findViewById(R.id.teacherEmail);
            post=itemView.findViewById(R.id.teacherPost);
            imageView=itemView.findViewById(R.id.teacherImage);

        }
    }
}

package com.example.ikgptuamritsaradmin.ui.Home;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;


import com.example.ikgptuamritsaradmin.R;
import com.smarteist.autoimageslider.IndicatorView.animation.type.IndicatorAnimationType;
import com.smarteist.autoimageslider.SliderAnimations;
import com.smarteist.autoimageslider.SliderView;

import java.util.ArrayList;

public class HomeFragment extends Fragment {
    private  int images[];
    private  String text[];
    private SliderAdapterExample adapter;
    private SliderView sliderView;
    private ImageView map;




    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);
        sliderView=view.findViewById(R.id.imageSlider);
        images= new int[]{R.drawable.asr3, R.drawable.asr1,R.drawable.asr2, R.drawable.asr4, R.drawable.logo1};
        text=new String[]{"IKGPTU Amritsar Campus","IKGPTU Amritsar Campus","IKGPTU Amritsar Campus","IKGPTU Amritsar Campus","IKGPTU Amritsar Campus"};
        adapter=new SliderAdapterExample(images,text);
        sliderView.setSliderAdapter(adapter);
        sliderView.setSliderTransformAnimation(SliderAnimations.SIMPLETRANSFORMATION);
        sliderView.setIndicatorAnimation(IndicatorAnimationType.SLIDE);
        sliderView.startAutoCycle();
        map=view.findViewById(R.id.map);
        map.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMap();
            }
        });

        return view;
    }

    private void openMap() {

        Uri gmmIntentUri = Uri.parse("geo:0,0?q=IKGPTU Amritsar Campus");
        Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
        mapIntent.setPackage("com.google.android.apps.maps");
        startActivity(mapIntent);
    }


}
package com.example.ikgptuamritsaradmin.ui.Gallery;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.ikgptuamritsaradmin.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;


public class GalleryFragment extends Fragment {
    RecyclerView technicalRecycler,otherRecycler,sportRecycler,culturalRecycler,nssRecycler,trainigRecycler;
    GalleryAdapter adapter;
    DatabaseReference reference;
    private ProgressBar progressBar1,progressBar2,progressBar3,progressBar4,progressBar5,progressBar6;
    private LinearLayout noData1,noData2,noData3,noData4,noData5,noData6;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_gallery, container, false);
        technicalRecycler=view.findViewById(R.id.technicalRecycler);
        otherRecycler=view.findViewById(R.id.otherRecycler);
        sportRecycler=view.findViewById(R.id.sportRecycler);
        culturalRecycler=view.findViewById(R.id.culturalRecycler);
        trainigRecycler=view.findViewById(R.id.trainigRecycler);
        nssRecycler=view.findViewById(R.id.nssRecycler);
        noData1=view.findViewById(R.id.noData1);
        noData2=view.findViewById(R.id.noData2);
        noData3=view.findViewById(R.id.noData3);
        noData4=view.findViewById(R.id.noData4);
        noData5=view.findViewById(R.id.noData5);
        noData6=view.findViewById(R.id.noData6);
        progressBar1=view.findViewById(R.id.progressBar1);
        progressBar2=view.findViewById(R.id.progressBar2);
        progressBar3=view.findViewById(R.id.progressBar3);
        progressBar4=view.findViewById(R.id.progressBar4);
        progressBar5=view.findViewById(R.id.progressBar5);
        progressBar6=view.findViewById(R.id.progressBar6);
        reference= FirebaseDatabase.getInstance().getReference().child("gallery");
        getsportRecycler();
         gettechnicalImage();
        getotherImage();
        getculturalRecycler();
        getnssRecycler();
        gettrainigRecycler();
        return view;
    }

    private void gettrainigRecycler() {

        reference.child("Training and Placement Events").addValueEventListener(new ValueEventListener() {
            List<String> imageList = new ArrayList<>();
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(!dataSnapshot.exists()){
                    noData5.setVisibility(View.VISIBLE);
                    trainigRecycler.setVisibility(View.GONE);
                    progressBar5.setVisibility(View.GONE);
                }else{
                    noData5.setVisibility(View.GONE);
                    trainigRecycler.setVisibility(View.VISIBLE);
                    for(DataSnapshot snapshot : dataSnapshot.getChildren()) {

                        String data = (String) snapshot.getValue();
                        imageList.add(data);

                    }
                    adapter =new GalleryAdapter(getContext(),imageList);
                    trainigRecycler.setLayoutManager(new GridLayoutManager(getContext(),3));

                    progressBar5.setVisibility(View.GONE);
                    trainigRecycler.setAdapter(adapter);
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                progressBar5.setVisibility(View.GONE);
                Toast.makeText(getContext(),databaseError.getMessage(), Toast.LENGTH_SHORT).show();


            }
        });
    }

    private void getnssRecycler() {
        reference= FirebaseDatabase.getInstance().getReference().child("gallery");
        reference.child("NSS Events").addValueEventListener(new ValueEventListener() {
            List<String> imageList = new ArrayList<>();
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(!dataSnapshot.exists()){
                    noData4.setVisibility(View.VISIBLE);
                    nssRecycler.setVisibility(View.GONE);
                    progressBar4.setVisibility(View.GONE);
                }else{
                    noData4.setVisibility(View.GONE);
                    nssRecycler.setVisibility(View.VISIBLE);
                    for(DataSnapshot snapshot : dataSnapshot.getChildren()) {

                        String data = (String) snapshot.getValue();
                        imageList.add(data);

                    }

                    adapter =new GalleryAdapter(getContext(),imageList);
                    nssRecycler.setLayoutManager(new GridLayoutManager(getContext(),3));
                    progressBar4.setVisibility(View.GONE);
                    nssRecycler.setAdapter(adapter);

                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                progressBar4.setVisibility(View.GONE);
                Toast.makeText(getContext(),databaseError.getMessage(), Toast.LENGTH_SHORT).show();


            }
        });
    }

    private void getculturalRecycler() {
        reference= FirebaseDatabase.getInstance().getReference().child("gallery");
        reference.child("Cultural Events").addValueEventListener(new ValueEventListener() {
            List<String> imageList = new ArrayList<>();
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(!dataSnapshot.exists()){
                    noData3.setVisibility(View.VISIBLE);
                    culturalRecycler.setVisibility(View.GONE);
                    progressBar3.setVisibility(View.GONE);
                }else{
                    noData3.setVisibility(View.GONE);
                    culturalRecycler.setVisibility(View.VISIBLE);
                    for(DataSnapshot snapshot : dataSnapshot.getChildren()) {

                        String data = (String) snapshot.getValue();
                        imageList.add(data);

                    }

                    adapter =new GalleryAdapter(getContext(),imageList);
                    culturalRecycler.setLayoutManager(new GridLayoutManager(getContext(),3));
                    progressBar3.setVisibility(View.GONE);
                    culturalRecycler.setAdapter(adapter);

                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                progressBar3.setVisibility(View.GONE);
                Toast.makeText(getContext(),databaseError.getMessage(), Toast.LENGTH_SHORT).show();


            }
        });
    }

    private void getsportRecycler() {
        reference= FirebaseDatabase.getInstance().getReference().child("gallery");
        reference.child("Sports Events").addValueEventListener(new ValueEventListener() {
            List<String> imageList = new ArrayList<>();
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(!dataSnapshot.exists()){
                    noData2.setVisibility(View.VISIBLE);
                    sportRecycler.setVisibility(View.GONE);
                    progressBar2.setVisibility(View.GONE);
                }else{
                    noData2.setVisibility(View.GONE);
                    sportRecycler.setVisibility(View.VISIBLE);
                    for(DataSnapshot snapshot : dataSnapshot.getChildren()) {

                        String data = (String) snapshot.getValue();
                        imageList.add(data);

                    }

                    adapter =new GalleryAdapter(getContext(),imageList);
                    sportRecycler.setLayoutManager(new GridLayoutManager(getContext(),3));
                    progressBar2.setVisibility(View.GONE);
                    sportRecycler.setAdapter(adapter);

                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
               progressBar2.setVisibility(View.GONE);
                Toast.makeText(getContext(),databaseError.getMessage(), Toast.LENGTH_SHORT).show();


            }
        });
    }

    private void gettechnicalImage() {
        reference= FirebaseDatabase.getInstance().getReference().child("gallery");
        reference.child("Technical Events").addValueEventListener(new ValueEventListener() {
            List<String> imageList = new ArrayList<>();
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(!dataSnapshot.exists()){
                    noData1.setVisibility(View.VISIBLE);
                    technicalRecycler.setVisibility(View.GONE);
                    progressBar1.setVisibility(View.GONE);
                }else{
                    noData1.setVisibility(View.GONE);
                    technicalRecycler.setVisibility(View.VISIBLE);
                    for(DataSnapshot snapshot : dataSnapshot.getChildren()) {

                        String data = (String) snapshot.getValue();
                        imageList.add(data);

                    }

                    adapter =new GalleryAdapter(getContext(),imageList);
                    technicalRecycler.setLayoutManager(new GridLayoutManager(getContext(),3));
                    progressBar1.setVisibility(View.GONE);
                    technicalRecycler.setAdapter(adapter);

                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
               progressBar1.setVisibility(View.GONE);
                Toast.makeText(getContext(),databaseError.getMessage(), Toast.LENGTH_SHORT).show();


            }
        });
    }

    private void getotherImage() {

        reference.child("Other Events").addValueEventListener(new ValueEventListener() {
            List<String> imageList = new ArrayList<>();
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(!dataSnapshot.exists()){
                    noData6.setVisibility(View.VISIBLE);
                    otherRecycler.setVisibility(View.GONE);
                    progressBar6.setVisibility(View.GONE);
                }else{
                    noData6.setVisibility(View.GONE);
                    otherRecycler.setVisibility(View.VISIBLE);
                    for(DataSnapshot snapshot : dataSnapshot.getChildren()) {

                        String data = (String) snapshot.getValue();
                        imageList.add(data);

                    }

                    adapter =new GalleryAdapter(getContext(),imageList);
                    otherRecycler.setLayoutManager(new GridLayoutManager(getContext(),3));
                    progressBar6.setVisibility(View.GONE);
                    otherRecycler.setAdapter(adapter);

                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                progressBar6.setVisibility(View.GONE);
               Toast.makeText(getContext(),databaseError.getMessage(), Toast.LENGTH_SHORT).show();


            }
        });

    }



}
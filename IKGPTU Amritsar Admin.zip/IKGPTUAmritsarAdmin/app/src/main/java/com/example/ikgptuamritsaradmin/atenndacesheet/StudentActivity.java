package com.example.ikgptuamritsaradmin.atenndacesheet;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.util.Pair;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.example.ikgptuamritsaradmin.R;

import java.util.ArrayList;

public class StudentActivity extends AppCompatActivity {
    Toolbar toolbar;
    private String className;
    private String subjectName;
    private int position;
    private RecyclerView recyclerView;
    private StudentAdapter adapter;
    private RecyclerView.LayoutManager layoutManager;
    DbHelper dbHelper;
    private int deletePosition;
    private long cid;
    private MyCalendar calendar;
    TextView subtitle;
    private ArrayList<StudentItem> studentItems=new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student);
        getSupportActionBar().hide();

        calendar = new MyCalendar();

        Intent intent=getIntent();
        className=intent.getStringExtra("className");
        subjectName=intent.getStringExtra("subjectName");
        position=intent.getIntExtra("position",-1);
        cid=intent.getLongExtra("cid",-1);

        setToolbar();
        recyclerView=findViewById(R.id.student_recycler);
        recyclerView.setHasFixedSize(true);
        layoutManager=new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        adapter=new StudentAdapter(this,studentItems);
        recyclerView.setAdapter(adapter);
        adapter.setOnItemClickListener(position->ChangedStaus(position));
        dbHelper=new DbHelper(this);
        loadData();
        loadStatusData();

    }

    private void ChangedStaus(int position) {
        String status = studentItems.get(position).getStatus();
        if (status.equals("P")) {
            status = "A";
        } else {
            status = "P";
        }
        studentItems.get(position).setStatus(status);
        adapter.notifyItemChanged(position);
    }

    private void loadData() {
        Cursor cursor = dbHelper.getStudentTable(cid);
        Log.i("123456789","loadData: "+cid);
        studentItems.clear();

        int idIndex = cursor.getColumnIndex(DbHelper.S_ID);
        int rollIndex = cursor.getColumnIndex(DbHelper.STUDENT_ROLL_KEY);
        int nameIndex = cursor.getColumnIndex(DbHelper.STUDENT_NAME_KEY);

// Check if any of the column indexes are missing (-1)
        if (idIndex < 0 || rollIndex < 0 || nameIndex < 0) {
            // Log an error or show a message indicating missing columns
            Log.e("LoadData", "One or more columns are missing in the cursor.");

            // Close the cursor to release resources
            cursor.close();
            return;
        }

        while (cursor.moveToNext()) {
            long sid = cursor.getLong(idIndex);
            int roll = cursor.getInt(rollIndex);
            String name = cursor.getString(nameIndex);

            studentItems.add(new StudentItem(sid, roll, name));
        }

        cursor.close();
    }


    private void setToolbar() {
        toolbar=findViewById(R.id.toolbar);
        subtitle=toolbar.findViewById(R.id.subtitle_toolbar);
        TextView title=toolbar.findViewById(R.id.title_toolbar);

        ImageButton back=toolbar.findViewById(R.id.back);
        ImageButton save=toolbar.findViewById(R.id.save);

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveStatus();
            }
        });

        title.setText(className);
        subtitle.setText(subjectName+" | "+calendar.getDate());

        back.setOnClickListener(v-> onBackPressed());
        toolbar.inflateMenu(R.menu.student_menu);
        toolbar.setOnMenuItemClickListener(menuItem->onMenuItemClick(menuItem));

    }


private void saveStatus() {
    Pair<Integer, Integer> presentAndAbsentCounts = calculatePresentAndAbsentCount();

    AlertDialog.Builder builder = new AlertDialog.Builder(this);
    builder.setTitle("Save Attendance");
    builder.setMessage("Present: " + presentAndAbsentCounts.first +
            "\nAbsent: " + presentAndAbsentCounts.second);
    builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
        @Override
        public void onClick(DialogInterface dialog, int which) {
            for (StudentItem studentItem : studentItems) {
                String status = studentItem.getStatus();
                if (!status.equals("P")) {
                    status = "A";
                }

                // Check if a status entry already exists for the student and date
                String existingStatus = dbHelper.getStatus(studentItem.getSid(), calendar.getDate());
                if (existingStatus != null) {
                    dbHelper.updateStatus(studentItem.getSid(), calendar.getDate(), status);
                } else {
                    dbHelper.addStatus(studentItem.getSid(), cid, calendar.getDate(), status);
                }
            }
            showToast("Data saved successfully");
        }
    });
    builder.setNegativeButton("Cancel", null);
    AlertDialog alertDialog = builder.create();
    alertDialog.show();
}


    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }



    private void loadStatusData() {
        for(StudentItem studentItem: studentItems){
            String status=dbHelper.getStatus(studentItem.getSid(),calendar.getDate());
            if(status!=null) studentItem.setStatus(status);
            else studentItem.setStatus("");

        }
        adapter.notifyDataSetChanged();
    }

    private Pair<Integer, Integer> calculatePresentAndAbsentCount() {
        int presentCount = 0;
        int absentCount = 0;

        for (StudentItem studentItem : studentItems) {
            if (studentItem.getStatus().equals("P")) {
                presentCount++;
            } else if (studentItem.getStatus().equals("A")) {
                absentCount++;
            }
        }

        return new Pair<>(presentCount, absentCount);
    }


    private boolean onMenuItemClick(MenuItem menuItem) {
        if(menuItem.getItemId()==R.id.add_student){
            showAddStudentDialog();
        }
        else if(menuItem.getItemId()==R.id.show_calendar){
            showCalendar();
        }
        else if(menuItem.getItemId()==R.id.show_attendance_sheet){
            openSheetList();
        }
        return true;
    }

    private void openSheetList() {
        long[] idArray=new long[studentItems.size()];
        String[] nameArray=new String[studentItems.size()];
        int[] rollArray=new int[studentItems.size()];
        for (int i=0;i<idArray.length;i++){
            idArray[i]=studentItems.get(i).getSid();
        }
        for (int i=0;i<rollArray.length;i++){
            rollArray[i]=studentItems.get(i).getRoll();
        }
        for (int i=0;i<nameArray.length;i++){
            nameArray[i]=studentItems.get(i).getName();
        }

        //
        Intent intent = new Intent(this, SheetlistActivity.class);
        intent.putExtra("className",className);
        intent.putExtra("subjectName",subjectName);
        intent.putExtra("position",position);
        intent.putExtra("cid", cid); // Pass the cid to SheetlistActivity
        //
        intent.putExtra("idArray",idArray);
        intent.putExtra("rollArray",rollArray);
        intent.putExtra("nameArray",nameArray);
        startActivity(intent);
    }

    private void showCalendar() {

        calendar.setOnCalendarokClickListener((year, month, day) -> onCalendarOkClicked(year, month, day));
        calendar.show(getSupportFragmentManager(), "");
    }

    private void onCalendarOkClicked(int year, int month, int day) {
        calendar.setDate(year, month, day);
        subtitle.setText(subjectName+" | "+calendar.getDate());
        loadStatusData();

    }

    private void showAddStudentDialog() {
        MyDialog dialog=new MyDialog();
        dialog.show(getSupportFragmentManager(), MyDialog.STUDENT_ADD_DIALOG);
        dialog.setListener((roll,name)->addStudent(roll,name));
    }

    private void addStudent(String roll_string, String name) {
        int roll=Integer.parseInt(roll_string);
        long sid=dbHelper.addStudent(cid,roll,name);
        StudentItem studentItem=new StudentItem(sid,roll,name);
        studentItems.add(studentItem);
        adapter.notifyDataSetChanged();
    }
    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case 0:
                showUpdateDialog(item.getGroupId());
                break;
            case 1:
                deletePosition = item.getGroupId(); // Store the position to be deleted
                showDeleteConfirmationDialog();
                break;
        }
        return super.onContextItemSelected(item);
    }

    private void showUpdateDialog(int position) {

        MyDialog dialog=new MyDialog();
        dialog.show(getSupportFragmentManager(), MyDialog.STUDENT_UPDATE_DIALOG);
        dialog.setListener((roll_string,name)->updateStudent(position,roll_string,name));
    }

    private void updateStudent(int position, String roll_String, String name) {
        int roll=Integer.parseInt(roll_String);
        dbHelper.updateStudent(studentItems.get(position).getSid(),roll,name);
        studentItems.get(position).setRoll(roll);
        studentItems.get(position).setName(name);
        adapter.notifyItemChanged(position);

    }
    private void showDeleteConfirmationDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Delete Class");
        builder.setMessage("Are you sure you want to delete this class?");
        builder.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                deleteStudent(deletePosition);
            }
        });
        builder.setNegativeButton("Cancel", null);
        AlertDialog alertDialog = builder.create(); // Create AlertDialog instance
        alertDialog.show();
    }
    private void deleteStudent(int position) {
        dbHelper.deleteStudent(studentItems.get(position).getSid());
        studentItems.remove(position);
        adapter.notifyItemRemoved(position);
    }
}